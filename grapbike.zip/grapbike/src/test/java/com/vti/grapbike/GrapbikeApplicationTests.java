package com.vti.grapbike;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrapbikeApplicationTests {

	@Test
	void contextLoads() {
	}

}
